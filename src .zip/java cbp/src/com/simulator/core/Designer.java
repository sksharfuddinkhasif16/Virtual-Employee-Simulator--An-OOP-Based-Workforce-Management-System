package com.simulator.core;

import com.simulator.exceptions.HighStressException;
import com.simulator.exceptions.LowEnergyException;

public class Designer extends Employee {
    public Designer(int id, String name, int productivity, int stress, int energy, int skills) {
        super(id, name, "Designer", productivity, stress, energy, skills);
    }

    @Override
    public void work() throws LowEnergyException, HighStressException {
        if (getEnergy() <= 5)
            throw new LowEnergyException(getName() + " is too tired to design.");
        if (getStress() >= 95)
            throw new HighStressException(getName() + " is too stressed to design.");

        // start an indefinite working action — remain WORKING until interrupted or
        // depleted
        startAction(EmployeeStatus.WORKING, -1L);

        int newEnergy = getEnergy() - 18;
        int newStress = getStress() + 8;
        int skillFactor = getSkills() / 11;
        int newProductivity = getProductivity() + 7 + skillFactor;

        setEnergy(newEnergy);
        setStress(newStress);
        setProductivity(newProductivity);

        System.out.println(getName() + " started designing.");
    }
}
