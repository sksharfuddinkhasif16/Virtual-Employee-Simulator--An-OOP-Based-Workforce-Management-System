package com.simulator.core;

public enum EmployeeStatus {
    IDLE,
    WORKING,
    TRAINING,
    RESTING,
    INACTIVE // newly added to mark employees who can no longer be used
}
