package com.simulator.core;

import com.simulator.exceptions.HighStressException;
import com.simulator.exceptions.LowEnergyException;

public class Tester extends Employee {
    public Tester(int id, String name, int productivity, int stress, int energy, int skills) {
        super(id, name, "Tester", productivity, stress, energy, skills);
    }

    @Override
    public void work() throws LowEnergyException, HighStressException {
        if (getEnergy() <= 5)
            throw new LowEnergyException(getName() + " is too tired to test.");
        if (getStress() >= 95)
            throw new HighStressException(getName() + " is too stressed to test.");

        // start an indefinite working action — remain WORKING until interrupted or
        // depleted
        startAction(EmployeeStatus.WORKING, -1L);

        int newEnergy = getEnergy() - 10;
        int newStress = getStress() + 6;
        int skillFactor = getSkills() / 12;
        int newProductivity = getProductivity() + 6 + skillFactor;

        setEnergy(newEnergy);
        setStress(newStress);
        setProductivity(newProductivity);

        System.out.println(getName() + " started testing.");
    }
}
