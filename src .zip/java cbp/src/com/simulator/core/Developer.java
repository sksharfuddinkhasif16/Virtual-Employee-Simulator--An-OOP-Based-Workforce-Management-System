package com.simulator.core;

import com.simulator.exceptions.HighStressException;
import com.simulator.exceptions.LowEnergyException;

/**
 * Developer-specific behavior: coding reduces energy more and increases stress
 * moderately.
 */
public class Developer extends Employee {
    public Developer(int id, String name, int productivity, int stress, int energy, int skills) {
        super(id, name, "Developer", productivity, stress, energy, skills);
    }

    @Override
    public void work() throws LowEnergyException, HighStressException {
        // Basic pre-checks
        if (getEnergy() <= 5) {
            throw new LowEnergyException(getName() + " does not have enough energy to work.");
        }
        if (getStress() >= 95) {
            throw new HighStressException(getName() + " is too stressed to work.");
        }

        // start an indefinite working action — remain WORKING until interrupted or
        // depleted
        startAction(EmployeeStatus.WORKING, -1L);

        int newEnergy = getEnergy() - 8;
        int newStress = getStress() + 5;
        int skillFactor = getSkills() / 5;
        int newProductivity = getProductivity() + 4 + skillFactor;

        setEnergy(newEnergy);
        setStress(newStress);
        setProductivity(newProductivity);

        System.out.println(getName() + " (Developer) is coding.");
        // setStatus(EmployeeStatus.IDLE);
    }
}
