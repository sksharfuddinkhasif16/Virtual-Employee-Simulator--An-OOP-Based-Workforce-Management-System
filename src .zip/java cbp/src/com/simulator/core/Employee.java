package com.simulator.core;

import com.simulator.exceptions.HighStressException;
import com.simulator.exceptions.LowEnergyException;

import java.io.Serializable;

public abstract class Employee implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int id;
    private String name;
    private String role;

    private int productivity;
    private int stress;
    private int energy;
    private int skills;

    // NEW: action status and until-when (ms since epoch)
    private EmployeeStatus status = EmployeeStatus.IDLE;
    private long busyUntil = 0L; // timestamp in millis
    // A simple tick-based busy counter used by SimulationThread and role
    // implementations
    private int busyTicks = 0;

    public Employee(int id, String name, String role,
            int productivity, int stress, int energy, int skills) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.productivity = clamp(productivity);
        this.stress = clamp(stress);
        this.energy = clamp(energy);
        this.skills = clamp(skills);
    }

    // NEW: start an action that lasts durationMillis
    protected void startAction(EmployeeStatus newStatus, long durationMillis) {
        if (this.status == EmployeeStatus.INACTIVE)
            return; // cannot start actions
        this.status = newStatus;
        if (durationMillis < 0L) {
            // negative duration signals an indefinite action (rest until externally
            // stopped)
            this.busyUntil = -1L;
        } else {
            this.busyUntil = System.currentTimeMillis() + Math.max(0, durationMillis);
        }
    }

    // NEW: make sure a manual setter exists if needed
    public EmployeeStatus getStatus() {
        // If status is WORKING/TRAINING/RESTING but busyUntil passed, return IDLE
        // Only auto-reset to IDLE when a busyUntil timestamp was set and has expired.
        if (status == EmployeeStatus.WORKING || status == EmployeeStatus.TRAINING || status == EmployeeStatus.RESTING) {
            // If action was started as "indefinite" (busyUntil == -1), treat as still busy
            if (busyUntil == -1L) {
                return status;
            }
            // If there's a timestamp-based busy marker, check expiry
            if (busyUntil > 0L) {
                if (System.currentTimeMillis() > busyUntil) {
                    status = EmployeeStatus.IDLE;
                    busyUntil = 0L;
                } else {
                    return status; // still busy by timestamp
                }
            } else if (busyTicks > 0) {
                return status; // still busy by tick counter
            } else {
                // No busy marker present -> consider the action finished
                status = EmployeeStatus.IDLE;
            }
        }
        return status;
    }

    public void setStatus(EmployeeStatus s) {
        this.status = s;
        if (s == EmployeeStatus.IDLE)
            this.busyUntil = 0L;
    }

    public long getBusyUntil() {
        return busyUntil;
    }

    public int getBusyTicks() {
        return busyTicks;
    }

    public void setBusyTicks(int busyTicks) {
        this.busyTicks = Math.max(0, busyTicks);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public int getProductivity() {
        return productivity;
    }

    public int getStress() {
        return stress;
    }

    public int getEnergy() {
        return energy;
    }

    public int getSkills() {
        return skills;
    }

    public void setProductivity(int productivity) {
        this.productivity = clamp(productivity);
    }

    public void setStress(int stress) {
        this.stress = clamp(stress);
    }

    public void setEnergy(int energy) {
        this.energy = clamp(energy);
    }

    public void setSkills(int skills) {
        this.skills = clamp(skills);
    }

    // keep previous methods (takeBreak, train, reward) — adjust them to use
    // startAction when appropriate
    public void takeBreak() {
        if (status == EmployeeStatus.INACTIVE) {
            // Allow a break to attempt a revival: restore some energy, reduce stress,
            // and ensure productivity is above 0 so the employee becomes active again.
            setEnergy(Math.min(100, Math.max(1, getEnergy() + 20)));
            setStress(Math.max(0, getStress() - 15));
            if (getProductivity() <= 0) {
                setProductivity(10); // give minimal productivity to avoid immediate re-inactivation
            }
            setBusyTicks(0);
            // After revival, start RESTING so break persists until work/train interrupts
            startAction(EmployeeStatus.RESTING, -1L);
            System.out.println(
                    getName() + " was inactive and has been revived; now RESTING until work or train is called.");
            return;
        }

        // Start an indefinite/rest-until-done break; SimulationThread will
        // incrementally restore attributes each tick and will clear RESTING
        // when recovery conditions are met or when work is called.
        startAction(EmployeeStatus.RESTING, -1L);
        // immediate effect
        setEnergy(Math.min(100, getEnergy() + 20));
        setStress(Math.max(0, getStress() - 15));
        System.out.println(getName() + " started resting until work or train is called.");
    }

    public void train() throws LowEnergyException {
        if (status == EmployeeStatus.INACTIVE) {
            System.out.println(getName() + " is inactive and cannot train.");
            return;
        }
        if (getEnergy() < 10) {
            throw new LowEnergyException(getName() + " is too tired to train.");
        }
        // Start indefinite training: TRAINING continues until interrupted by work
        // or skills reach their natural cap; per-tick skill/energy changes are
        // applied by SimulationThread.
        startAction(EmployeeStatus.TRAINING, -1L);
        System.out.println(getName() + " started training (ongoing) until interrupted by work or stopped manually.");
    }

    public void reward() {
        if (status == EmployeeStatus.INACTIVE) {
            System.out.println(getName() + " is inactive and cannot be rewarded.");
            return;
        }
        setProductivity(Math.min(100, getProductivity() + 15));
        setStress(Math.max(0, getStress() - 10));
        System.out.println(getName() + " has been rewarded. Productivity boosted!");
    }

    // clamp
    private int clamp(int value) {
        if (value < 0)
            return 0;
        if (value > 100)
            return 100;
        return value;
    }

    // Abstract work signature now throws exceptions if you used them
    public abstract void work() throws LowEnergyException, HighStressException;

    public void showStatus() {
        System.out.println("\n--- Employee Status ---");
        System.out.printf("ID          : %d%n", id);
        System.out.printf("Name        : %s%n", name);
        System.out.printf("Role        : %s%n", role);
        System.out.printf("Status      : %s%n", getStatus());
        System.out.printf("Productivity: %d%n", productivity);
        System.out.printf("Stress      : %d%n", stress);
        System.out.printf("Energy      : %d%n", energy);
        System.out.printf("Skills      : %d%n", skills);
        System.out.println("------------------------");
    }
}
