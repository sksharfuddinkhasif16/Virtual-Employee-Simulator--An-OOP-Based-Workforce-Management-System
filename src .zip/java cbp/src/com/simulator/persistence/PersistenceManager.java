package com.simulator.persistence;

import com.simulator.core.Employee;
import com.simulator.manager.EmployeeManager;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Simple persistence manager that saves and loads a collection of Employee
 * objects.
 * Uses Java Serialization to a single file "employees.dat".
 */
public class PersistenceManager {

    // Save all employees to file
    public static void saveEmployees(Collection<Employee> employees, String filename) throws IOException {
        List<Employee> list = new ArrayList<>(employees); // serializable list
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(list);
        }
    }

    // Load employees from file and return list; caller should add them back to
    // manager.
    public static List<Employee> loadEmployees(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            Object obj = ois.readObject();
            @SuppressWarnings("unchecked")
            List<Employee> list = (List<Employee>) obj;
            return list;
        }
    }
}
