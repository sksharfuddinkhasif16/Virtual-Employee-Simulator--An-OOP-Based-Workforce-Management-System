package com.simulator.sim;

import com.simulator.core.Employee;
import com.simulator.core.EmployeeStatus;
import com.simulator.core.Developer;
import com.simulator.core.Tester;
import com.simulator.core.Designer;
import com.simulator.manager.EmployeeManager;

import java.util.Collection;

/**
 * Simulation loop:
 * - Handles RESTING/WORKING/TRAINING/IDLE differently
 * - Decrements busyTicks; when busyTicks reaches 0 and status was
 * WORKING/TRAINING,
 * sets status to IDLE automatically.
 * - If energy <= 0 OR stress >= 100 OR productivity <= 0 -> mark INACTIVE and
 * print message.
 */
public class SimulationThread extends Thread {
    private final EmployeeManager manager;
    private volatile boolean running = true;
    private final long tickMillis;

    public SimulationThread(EmployeeManager manager, long tickMillis) {
        this.manager = manager;
        this.tickMillis = tickMillis;
        setDaemon(true);
    }

    public SimulationThread(EmployeeManager manager) {
        this(manager, 3000); // faster tick for responsiveness (3s)
    }

    @Override
    public void run() {
        while (running) {
            Collection<Employee> all = manager.getAllEmployees();
            for (Employee e : all) {

                // If employee became INACTIVE already, skip
                if (e.getStatus() == EmployeeStatus.INACTIVE)
                    continue;

                // Main status behaviour
                EmployeeStatus s = e.getStatus();
                switch (s) {
                    case RESTING -> {
                        // Resting: gradual recovery
                        e.setEnergy(e.getEnergy() + 4);
                        e.setStress(e.getStress() - 3);
                    }
                    case WORKING -> {
                        // Role-specific working deltas per tick
                        if (e instanceof Developer) {
                            // Developer: moderate energy drain, moderate stress increase, productivity gain
                            e.setEnergy(e.getEnergy() - 4);
                            e.setStress(e.getStress() + 3);
                            int skillFactor = e.getSkills() / 10;
                            e.setProductivity(e.getProductivity() + 1 + skillFactor);
                        } else if (e instanceof Tester) {
                            // Tester: milder energy drain, smaller stress increase, small productivity gain
                            e.setEnergy(e.getEnergy() - 3);
                            e.setStress(e.getStress() + 2);
                            int skillFactor = e.getSkills() / 12;
                            e.setProductivity(e.getProductivity() + 1 + skillFactor);
                        } else if (e instanceof Designer) {
                            // Designer: higher energy drain, higher stress increase, higher productivity
                            // gain
                            e.setEnergy(e.getEnergy() - 5);
                            e.setStress(e.getStress() + 4);
                            int skillFactor = e.getSkills() / 11;
                            e.setProductivity(e.getProductivity() + 2 + skillFactor);
                        } else {
                            // Generic working behavior
                            e.setEnergy(e.getEnergy() - 3);
                            e.setStress(e.getStress() + 2);
                            e.setProductivity(e.getProductivity() + 1);
                        }
                    }
                    case TRAINING -> {
                        // Training: costs energy but increases skills slowly and may lower productivity
                        // briefly
                        e.setEnergy(e.getEnergy() - 3);
                        e.setStress(e.getStress() + 1);
                        // small skill gain over time
                        e.setSkills(Math.min(100, e.getSkills() + 1));
                    }
                    case IDLE -> {
                        e.setEnergy(e.getEnergy() - 1);
                        e.setStress(e.getStress() + 1);
                    }
                    default -> {
                        e.setEnergy(e.getEnergy() - 1);
                        e.setStress(e.getStress() + 1);
                    }
                }

                // Busy ticks handling: if busy, decrement; when 0, set IDLE
                if (e.getBusyTicks() > 0) {
                    e.setBusyTicks(e.getBusyTicks() - 1);
                    if (e.getBusyTicks() == 0 && (s == EmployeeStatus.WORKING || s == EmployeeStatus.TRAINING)) {
                        e.setStatus(EmployeeStatus.IDLE);
                    }
                }

                // Additional rules: low energy increases stress and reduces productivity
                if (e.getEnergy() < 15) {
                    e.setStress(e.getStress() + 2);
                    e.setProductivity(e.getProductivity() - 3);
                }

                // High stress reduces productivity
                if (e.getStress() > 90) {
                    e.setProductivity(e.getProductivity() - 4);
                }

                // Check inactive condition: any absolute failure condition
                // NOTE: if an employee is RESTING we allow them to recover; do not mark
                // them INACTIVE while resting so Break can revive depleted employees.
                if (e.getStatus() != EmployeeStatus.RESTING
                        && (e.getEnergy() <= 0 || e.getStress() >= 100 || e.getProductivity() <= 0)) {
                    // Mark inactive and print a one-time message
                    e.setStatus(EmployeeStatus.INACTIVE);
                    System.out.println("\n⚠ Employee ID " + e.getId() + " (" + e.getName() + ") has become INACTIVE.");
                    System.out.println("  Reason(s): "
                            + (e.getEnergy() <= 0 ? "energy depleted " : "")
                            + (e.getStress() >= 100 ? "stress too high " : "")
                            + (e.getProductivity() <= 0 ? "productivity collapsed" : ""));
                }

                // clamp attributes in case they drift
                e.setEnergy(e.getEnergy());
                e.setStress(e.getStress());
                e.setProductivity(e.getProductivity());
            }

            try {
                Thread.sleep(tickMillis);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void stopSimulation() {
        running = false;
        this.interrupt();
    }
}
