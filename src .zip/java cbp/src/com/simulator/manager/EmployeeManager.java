package com.simulator.manager;

import com.simulator.core.Employee;
import com.simulator.exceptions.EmployeeNotFoundException;
import com.simulator.core.EmployeeStatus;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Manager that stores employees by integer ID.
 * simple auto-increment id generator is included.
 */
public class EmployeeManager {
    private final Map<Integer, Employee> employees = new HashMap<>();
    private int nextId = 1;
    // Simple manager password for creating new employees. Default is "admin".
    private final String managerPassword;

    // Create and register employee, returns created employee
    public Employee createEmployee(String role, String name,
            int productivity, int stress, int energy, int skills) {
        int id = nextId++;
        Employee e;
        switch (role.toLowerCase()) {
            case "developer" -> e = new com.simulator.core.Developer(id, name, productivity, stress, energy, skills);
            case "tester" -> e = new com.simulator.core.Tester(id, name, productivity, stress, energy, skills);
            case "designer" -> e = new com.simulator.core.Designer(id, name, productivity, stress, energy, skills);
            default -> throw new IllegalArgumentException("Unknown role: " + role);
        }
        employees.put(id, e);
        return e;
    }

    /**
     * Create and register an employee with a specific ID. Throws
     * IllegalArgumentException if the ID is already taken.
     */
    public Employee createEmployeeWithId(String role, String name, int id,
            int productivity, int stress, int energy, int skills) {
        if (employees.containsKey(id))
            throw new IllegalArgumentException("Employee ID already exists: " + id);
        Employee e;
        switch (role.toLowerCase()) {
            case "developer" -> e = new com.simulator.core.Developer(id, name, productivity, stress, energy, skills);
            case "tester" -> e = new com.simulator.core.Tester(id, name, productivity, stress, energy, skills);
            case "designer" -> e = new com.simulator.core.Designer(id, name, productivity, stress, energy, skills);
            default -> throw new IllegalArgumentException("Unknown role: " + role);
        }
        employees.put(id, e);
        if (id >= nextId)
            nextId = id + 1;
        return e;
    }

    /**
     * Create a manager with default password "admin".
     */
    public EmployeeManager() {
        this("admin");
    }

    /**
     * Create a manager with a specific password.
     */
    public EmployeeManager(String password) {
        this.managerPassword = password == null ? "" : password;
    }

    /**
     * Check whether the provided password matches the manager password.
     */
    public boolean authenticate(String password) {
        if (password == null)
            return false;
        return managerPassword.equals(password);
    }

    public Employee addExistingEmployee(Employee e) {
        employees.put(e.getId(), e);
        // ensure nextId moves forward if loading serialized data
        if (e.getId() >= nextId)
            nextId = e.getId() + 1;
        return e;
    }

    public Employee getEmployee(int id) throws EmployeeNotFoundException {
        Employee e = employees.get(id);
        if (e == null)
            throw new EmployeeNotFoundException("Employee with ID " + id + " not found.");
        return e;
    }

    public Collection<Employee> getAllEmployees() {
        return employees.values();
    }

    public void showAllEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employees in the system.");
            return;
        }
        for (Employee e : employees.values())
            e.showStatus();
    }

    /**
     * Reactivate an employee by restoring safe attribute values and clearing busy
     * state.
     * This is intended for manager use only.
     */
    public void reactivateEmployee(int id, int energy, int stress, int productivity) throws EmployeeNotFoundException {
        Employee e = getEmployee(id);
        // enforce safe bounds
        e.setEnergy(Math.max(1, Math.min(100, energy)));
        e.setStress(Math.max(0, Math.min(99, stress)));
        e.setProductivity(Math.max(1, Math.min(100, productivity)));
        e.setBusyTicks(0);
        e.setStatus(EmployeeStatus.IDLE);
    }
}
