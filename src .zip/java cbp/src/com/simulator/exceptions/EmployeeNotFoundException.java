package com.simulator.exceptions;

/**
 * Thrown when an employee ID is not found in the manager.
 */
public class EmployeeNotFoundException extends Exception {
    public EmployeeNotFoundException(String message) {
        super(message);
    }
}
