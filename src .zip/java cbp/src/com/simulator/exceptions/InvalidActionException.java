package com.simulator.exceptions;

/**
 * Thrown when user selects an invalid menu/action option.
 */
public class InvalidActionException extends Exception {
    public InvalidActionException(String message) {
        super(message);
    }
}
