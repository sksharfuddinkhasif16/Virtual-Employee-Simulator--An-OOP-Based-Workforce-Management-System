package com.simulator.exceptions;

/**
 * Thrown when an employee attempts to do energy-consuming actions with too
 * little energy.
 */
public class LowEnergyException extends Exception {
    public LowEnergyException(String message) {
        super(message);
    }
}
