package com.simulator.exceptions;

/**
 * Thrown when an action cannot be performed because the employee is too
 * stressed.
 */
public class HighStressException extends Exception {
    public HighStressException(String message) {
        super(message);
    }
}
