package com.simulator.app.ui;

import com.simulator.core.Employee;
import com.simulator.manager.EmployeeManager;
import com.simulator.persistence.PersistenceManager;
import com.simulator.sim.SimulationThread;
import com.simulator.core.EmployeeStatus;
import com.simulator.exceptions.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
// removed unused event imports
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {
    private final EmployeeManager manager;
    private final SimulationThread sim;

    private final DefaultListModel<String> listModel = new DefaultListModel<>();
    private final JList<String> employeeList = new JList<>(listModel);
    private final JTextField searchField = new JTextField();
    private final JComboBox<String> sortCombo = new JComboBox<>(new String[] { "ID", "Name", "Role", "Status" });

    // Rich details components
    private final JPanel detailsPanel = new JPanel(new BorderLayout(8, 8));
    private final JLabel titleLabel = new JLabel("No employee selected");
    private final JLabel idLabel = new JLabel("");
    private final JLabel roleLabel = new JLabel("");
    private final JLabel statusLabel = new JLabel("");
    private final JProgressBar prodBar = new JProgressBar(0, 100);
    private final JProgressBar stressBar = new JProgressBar(0, 100);
    private final JProgressBar energyBar = new JProgressBar(0, 100);
    private final JProgressBar skillsBar = new JProgressBar(0, 100);
    private final Map<Integer, String> errorMap = new HashMap<>();
    private final JLabel errorLabel = new JLabel("");
    // Action buttons (moved to fields so we can enable/disable them)
    private JButton addBtn;
    private JButton workBtn;
    private JButton breakBtn;
    private JButton trainBtn;
    private JButton rewardBtn;
    private JButton stopBtn;
    private JButton reactBtn;
    private final JLabel statusBar = new JLabel(" ");

    public MainFrame(EmployeeManager manager, SimulationThread sim) {
        super("SimuWork");
        this.manager = manager;
        this.sim = sim;
        // Try to apply a modern look and feel (Nimbus preferred)
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignore) {
            }
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        initUI();

        // periodic refresh
        Timer t = new Timer(1000, e -> refreshEmployees());
        t.start();

        refreshEmployees();
    }

    // Apply a consistent, modern style to buttons
    private void styleButton(JButton b, String tooltip) {
        Font btnFont = new Font("Segoe UI", Font.PLAIN, 14);
        b.setFont(btnFont);
        b.setPreferredSize(new Dimension(180, 38));
        b.setMaximumSize(new Dimension(Short.MAX_VALUE, 40));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)),
                new EmptyBorder(6, 12, 6, 12)));
        b.setBackground(new Color(66, 133, 244));
        b.setForeground(Color.WHITE);
        b.setOpaque(true);
        b.setToolTipText(tooltip);
    }

    private void initUI() {
        // menu bar (File -> Save, Load, Exit)
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem saveItem = new JMenuItem("Save");
        saveItem.addActionListener(ev -> onSave());
        saveItem.setAccelerator(KeyStroke.getKeyStroke("control S"));
        JMenuItem loadItem = new JMenuItem("Load");
        loadItem.addActionListener(ev -> onLoad());
        loadItem.setAccelerator(KeyStroke.getKeyStroke("control L"));
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(ev -> onExit());
        exitItem.setAccelerator(KeyStroke.getKeyStroke("control Q"));
        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(root);

        // Top toolbar: search + sort + quick save/load
        JPanel toolbar = new JPanel();
        toolbar.setLayout(new BoxLayout(toolbar, BoxLayout.X_AXIS));
        toolbar.setBorder(new EmptyBorder(4, 4, 8, 4));
        searchField.setMaximumSize(new Dimension(300, 28));
        searchField.setToolTipText("Filter employees by id, name or role");
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                refreshEmployees();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                refreshEmployees();
            }

            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                refreshEmployees();
            }
        });
        toolbar.add(new JLabel("Search: "));
        toolbar.add(Box.createHorizontalStrut(6));
        toolbar.add(searchField);
        toolbar.add(Box.createHorizontalStrut(12));
        toolbar.add(new JLabel("Sort: "));
        sortCombo.setMaximumSize(new Dimension(120, 28));
        sortCombo.addActionListener(e -> refreshEmployees());
        toolbar.add(sortCombo);
        toolbar.add(Box.createHorizontalGlue());
        // Save/Load remain in File menu only (no quick buttons here)
        root.add(toolbar, BorderLayout.NORTH);

        // Left: list
        employeeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        employeeList.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        JScrollPane listScroll = new JScrollPane(employeeList);
        listScroll.setPreferredSize(new Dimension(340, 400));
        root.add(listScroll, BorderLayout.WEST);

        // Popup menu for quick actions
        JPopupMenu listPopup = new JPopupMenu();
        JMenuItem miWork = new JMenuItem("Work");
        miWork.addActionListener(ev -> onPerformAction("work"));
        listPopup.add(miWork);
        JMenuItem miBreak = new JMenuItem("Break");
        miBreak.addActionListener(ev -> onPerformAction("break"));
        listPopup.add(miBreak);
        JMenuItem miTrain = new JMenuItem("Train");
        miTrain.addActionListener(ev -> onPerformAction("train"));
        listPopup.add(miTrain);
        JMenuItem miReward = new JMenuItem("Reward");
        miReward.addActionListener(ev -> onPerformAction("reward"));
        listPopup.add(miReward);
        employeeList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int idx = employeeList.locationToIndex(e.getPoint());
                    if (idx >= 0) {
                        employeeList.setSelectedIndex(idx);
                        listPopup.show(employeeList, e.getX(), e.getY());
                    }
                } else if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    // double-click: open a quick details dialog
                    Integer id = getSelectedEmployeeId();
                    if (id != null) {
                        try {
                            Employee emp = manager.getEmployee(id);
                            JOptionPane.showMessageDialog(MainFrame.this,
                                    String.format(
                                            "%s (ID %d)\nRole: %s\nStatus: %s\nProd:%d Stress:%d Energy:%d Skills:%d",
                                            emp.getName(), emp.getId(), emp.getRole(), emp.getStatus(),
                                            emp.getProductivity(), emp.getStress(), emp.getEnergy(), emp.getSkills()),
                                    "Employee Details", JOptionPane.INFORMATION_MESSAGE);
                        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
                            // ignore
                        }
                    }
                }
            }
        });

        // Center: rich details panel
        titleLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        roleLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        statusLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        statusLabel.setOpaque(true);

        JPanel top = new JPanel(new BorderLayout(6, 6));
        // Place title (and ID) in CENTER so it can use available space and won't
        // overlap
        // the right-side role/status area when the window is resized.
        JPanel titleBlock = new JPanel();
        titleBlock.setLayout(new BoxLayout(titleBlock, BoxLayout.Y_AXIS));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        idLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        idLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        idLabel.setForeground(Color.DARK_GRAY);
        titleBlock.add(titleLabel);
        titleBlock.add(idLabel);
        top.add(titleBlock, BorderLayout.CENTER);
        JPanel topRight = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        roleLabel.setBorder(new EmptyBorder(0, 0, 0, 8));
        statusLabel.setBorder(new EmptyBorder(4, 8, 4, 8));
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topRight.add(roleLabel);
        topRight.add(statusLabel);
        top.add(topRight, BorderLayout.EAST);

        JPanel bars = new JPanel();
        bars.setLayout(new GridLayout(4, 1, 6, 6));

        prodBar.setStringPainted(true);
        prodBar.setForeground(new Color(34, 139, 34)); // forest green
        stressBar.setStringPainted(true);
        stressBar.setForeground(new Color(220, 50, 47)); // red
        energyBar.setStringPainted(true);
        energyBar.setForeground(new Color(70, 130, 180)); // steel blue
        skillsBar.setStringPainted(true);
        skillsBar.setForeground(new Color(138, 43, 226)); // blueviolet

        bars.add(wrapBar("Productivity", prodBar));
        bars.add(wrapBar("Stress", stressBar));
        bars.add(wrapBar("Energy", energyBar));
        bars.add(wrapBar("Skills", skillsBar));

        // Error label shows the last action-blocking message for the selected
        // employee (if any)
        errorLabel.setForeground(new Color(180, 30, 30));
        errorLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        errorLabel.setBorder(new EmptyBorder(6, 6, 6, 6));
        JPanel errorPanel = new JPanel(new BorderLayout());
        errorPanel.add(errorLabel, BorderLayout.CENTER);
        detailsPanel.add(errorPanel, BorderLayout.SOUTH);

        detailsPanel.setBorder(BorderFactory.createTitledBorder("Details"));
        detailsPanel.add(top, BorderLayout.NORTH);
        detailsPanel.add(bars, BorderLayout.CENTER);

        root.add(detailsPanel, BorderLayout.CENTER);

        // Right: actions
        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setPreferredSize(new Dimension(300, 400));

        addBtn = new JButton("Add Employee (Manager)");
        addBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        addBtn.addActionListener(e -> onAddEmployee());
        styleButton(addBtn, "Add a new employee (manager only)");
        right.add(addBtn);
        right.add(Box.createVerticalStrut(10));

        workBtn = new JButton("Work");
        workBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        workBtn.addActionListener(e -> onPerformAction("work"));
        styleButton(workBtn, "Start working (subject to energy/stress checks)");
        right.add(workBtn);
        right.add(Box.createVerticalStrut(6));

        breakBtn = new JButton("Break");
        breakBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        breakBtn.addActionListener(e -> onPerformAction("break"));
        styleButton(breakBtn, "Take a break / attempt to recover");
        right.add(breakBtn);
        right.add(Box.createVerticalStrut(6));

        trainBtn = new JButton("Train");
        trainBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        trainBtn.addActionListener(e -> onPerformAction("train"));
        styleButton(trainBtn, "Start training to increase skills");
        right.add(trainBtn);
        right.add(Box.createVerticalStrut(6));

        rewardBtn = new JButton("Reward");
        rewardBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        rewardBtn.addActionListener(e -> onPerformAction("reward"));
        styleButton(rewardBtn, "Reward an employee (boost productivity)");
        right.add(rewardBtn);
        right.add(Box.createVerticalStrut(12));

        stopBtn = new JButton("Stop Current Action (Manager)");
        stopBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        stopBtn.addActionListener(e -> onStopAction());
        styleButton(stopBtn, "Manager: stop the employee's current action");
        right.add(stopBtn);
        right.add(Box.createVerticalStrut(6));

        reactBtn = new JButton("Reactivate (Manager)");
        reactBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        reactBtn.addActionListener(e -> onReactivate());
        styleButton(reactBtn, "Manager: revive and reset an employee");
        right.add(reactBtn);
        right.add(Box.createVerticalStrut(12));

        // Save/Load/Exit are available via the File menu (top). They were removed
        // from the right-side action panel to avoid duplication.

        root.add(right, BorderLayout.EAST);

        // colored list renderer and selection listener
        employeeList.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {
            DefaultListCellRenderer dl = new DefaultListCellRenderer();
            JLabel lbl = (JLabel) dl.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            try {
                String s = value == null ? "" : value.toString();
                String[] parts = s.split(" - ");
                int id = Integer.parseInt(parts[0].trim());
                Employee e = manager.getEmployee(id);
                EmployeeStatus st = e.getStatus();
                switch (st) {
                    case WORKING -> lbl.setBackground(new Color(255, 244, 179));
                    case RESTING -> lbl.setBackground(new Color(213, 245, 217));
                    case TRAINING -> lbl.setBackground(new Color(207, 235, 245));
                    case INACTIVE -> lbl.setBackground(new Color(224, 224, 224));
                    default -> lbl.setBackground(Color.WHITE);
                }
            } catch (Exception ex) {
                // fallback
                lbl.setBackground(Color.WHITE);
            }
            return lbl;
        });
        employeeList.addListSelectionListener(e -> {
            showSelectedDetails();
            updateActionButtons();
        });

        // Status bar
        statusBar.setBorder(new EmptyBorder(6, 6, 6, 6));
        root.add(statusBar, BorderLayout.SOUTH);
    }

    private void refreshEmployees() {
        // preserve selection
        int sel = employeeList.getSelectedIndex();
        listModel.clear();
        String q = searchField.getText().trim().toLowerCase();
        String sort = (String) sortCombo.getSelectedItem();
        List<Employee> list = manager.getAllEmployees().stream()
                .filter(emp -> {
                    if (q.isEmpty())
                        return true;
                    String composite = emp.getId() + " " + emp.getName() + " " + emp.getRole() + " " + emp.getStatus();
                    return composite.toLowerCase().contains(q);
                })
                .sorted((a, b) -> {
                    return switch (sort == null ? "ID" : sort) {
                        case "Name" -> a.getName().compareToIgnoreCase(b.getName());
                        case "Role" -> a.getRole().compareToIgnoreCase(b.getRole());
                        case "Status" -> a.getStatus().toString().compareTo(b.getStatus().toString());
                        default -> Integer.compare(a.getId(), b.getId());
                    };
                })
                .collect(Collectors.toList());
        for (Employee emp : list) {
            // generate simulation-derived alerts
            String simMsg = null;
            if (emp.getEnergy() <= 15)
                simMsg = (simMsg == null) ? "Low energy" : simMsg + "; Low energy";
            if (emp.getStress() >= 80)
                simMsg = (simMsg == null) ? "High stress" : simMsg + "; High stress";
            if (emp.getStatus() == EmployeeStatus.INACTIVE)
                simMsg = (simMsg == null) ? "Inactive" : simMsg + "; Inactive";
            // merge simulation alerts into errorMap unless an ACTION message exists
            String existing = errorMap.get(emp.getId());
            if (existing == null || existing.startsWith("SIM: ")) {
                if (simMsg != null) {
                    errorMap.put(emp.getId(), "SIM: " + simMsg);
                } else {
                    if (existing != null && existing.startsWith("SIM: "))
                        errorMap.remove(emp.getId());
                }
            }

            String entry = String.format("%d - %s (%s) - %s", emp.getId(), emp.getName(), emp.getRole(),
                    emp.getStatus());
            if (errorMap.containsKey(emp.getId())) {
                entry += " ⚠";
            }
            listModel.addElement(entry);
        }
        if (sel >= 0 && sel < listModel.size())
            employeeList.setSelectedIndex(sel);
        showSelectedDetails();
        // Update status bar and button states; show count of alerts
        long alerts = errorMap.size();
        statusBar.setText(String.format("Employees: %d    |    Alerts: %d    |    Simulation: %s", list.size(), alerts,
                (sim != null && sim.isAlive()) ? "Running" : "Stopped"));
        updateActionButtons();
    }

    private void updateActionButtons() {
        boolean hasSelection = getSelectedEmployeeId() != null;
        workBtn.setEnabled(hasSelection);
        breakBtn.setEnabled(hasSelection);
        trainBtn.setEnabled(hasSelection);
        rewardBtn.setEnabled(hasSelection);
        stopBtn.setEnabled(hasSelection);
        reactBtn.setEnabled(hasSelection);
    }

    private Integer getSelectedEmployeeId() {
        String sel = employeeList.getSelectedValue();
        if (sel == null)
            return null;
        try {
            String[] parts = sel.split(" - ");
            return Integer.parseInt(parts[0].trim());
        } catch (Exception ex) {
            return null;
        }
    }

    private JPanel wrapBar(String label, JProgressBar bar) {
        JPanel p = new JPanel(new BorderLayout(6, 6));
        JLabel l = new JLabel(label + ": ");
        l.setPreferredSize(new Dimension(110, 20));
        p.add(l, BorderLayout.WEST);
        p.add(bar, BorderLayout.CENTER);
        return p;
    }

    private void showSelectedDetails() {
        Integer id = getSelectedEmployeeId();
        if (id == null) {
            titleLabel.setText("No employee selected");
            roleLabel.setText("");
            statusLabel.setText("");
            prodBar.setValue(0);
            prodBar.setString("");
            stressBar.setValue(0);
            stressBar.setString("");
            energyBar.setValue(0);
            energyBar.setString("");
            skillsBar.setValue(0);
            skillsBar.setString("");
            statusLabel.setBackground(null);
            return;
        }
        try {
            Employee e = manager.getEmployee(id);
            titleLabel.setText(e.getName());
            idLabel.setText("ID: " + e.getId());
            roleLabel.setText(e.getRole());
            EmployeeStatus st = e.getStatus();
            statusLabel.setText(st.toString());
            switch (st) {
                case WORKING -> statusLabel.setBackground(new Color(255, 210, 105));
                case RESTING -> statusLabel.setBackground(new Color(200, 245, 200));
                case TRAINING -> statusLabel.setBackground(new Color(200, 230, 245));
                case INACTIVE -> statusLabel.setBackground(new Color(200, 200, 200));
                default -> statusLabel.setBackground(new Color(240, 240, 240));
            }

            prodBar.setValue(e.getProductivity());
            prodBar.setString(e.getProductivity() + "%");
            stressBar.setValue(e.getStress());
            stressBar.setString(e.getStress() + "%");
            energyBar.setValue(e.getEnergy());
            energyBar.setString(e.getEnergy() + "%");
            skillsBar.setValue(e.getSkills());
            skillsBar.setString(e.getSkills() + "%");
            // show any stored error for this employee
            String raw = errorMap.get(e.getId());
            if (raw != null && !raw.isEmpty()) {
                String display = raw;
                if (raw.startsWith("ACTION: "))
                    display = raw.substring(8);
                else if (raw.startsWith("SIM: "))
                    display = raw.substring(5);
                errorLabel.setText("⚠ " + display);
                errorLabel.setVisible(true);
            } else {
                errorLabel.setText("");
                errorLabel.setVisible(false);
            }
        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
            titleLabel.setText("Employee not found.");
            roleLabel.setText("");
            statusLabel.setText("");
            statusLabel.setBackground(null);
        }
    }

    private void onAddEmployee() {
        JPasswordField pf = new JPasswordField();
        int okCxl = JOptionPane.showConfirmDialog(this, pf, "Enter manager password:", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (okCxl != JOptionPane.OK_OPTION)
            return;
        String pw = new String(pf.getPassword()).trim();
        if (!manager.authenticate(pw)) {
            JOptionPane.showMessageDialog(this, "Invalid manager password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String name = JOptionPane.showInputDialog(this, "Enter name:");
        if (name == null || name.trim().isEmpty())
            return;

        String[] roles = { "Developer", "Tester", "Designer" };
        String role = (String) JOptionPane.showInputDialog(this, "Choose role:", "Role",
                JOptionPane.QUESTION_MESSAGE, null, roles, roles[0]);
        if (role == null)
            return;

        try {
            String idStr = JOptionPane.showInputDialog(this, "Set ID (optional, leave blank for auto):");
            int p = Integer.parseInt(JOptionPane.showInputDialog(this, "Starting Productivity (0-100):"));
            int s = Integer.parseInt(JOptionPane.showInputDialog(this, "Starting Stress (0-100):"));
            int e = Integer.parseInt(JOptionPane.showInputDialog(this, "Starting Energy (0-100):"));
            int sk = Integer.parseInt(JOptionPane.showInputDialog(this, "Starting Skills (0-100):"));

            Employee emp;
            if (idStr == null || idStr.trim().isEmpty()) {
                emp = manager.createEmployee(role, name, p, s, e, sk);
            } else {
                try {
                    int id = Integer.parseInt(idStr.trim());
                    emp = manager.createEmployeeWithId(role, name, id, p, s, e, sk);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid ID number", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "Added employee with ID: " + emp.getId());
            refreshEmployees();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid numeric input", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onPerformAction(String action) {
        Integer id = getSelectedEmployeeId();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Select an employee first.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            Employee e = manager.getEmployee(id);
            switch (action) {
                case "work":
                    try {
                        e.work();
                        // clear any previous blocking error for this employee
                        errorMap.remove(e.getId());
                        JOptionPane.showMessageDialog(this, e.getName() + " started working.");
                    } catch (LowEnergyException | HighStressException ex) {
                        // store the blocking message (mark as ACTION) so it shows in the UI
                        errorMap.put(e.getId(), "ACTION: " + ex.getMessage());
                        // ensure the selected details show the error immediately
                        showSelectedDetails();
                        JOptionPane.showMessageDialog(this, ex.getMessage(), "Action blocked",
                                JOptionPane.WARNING_MESSAGE);
                    }
                    break;
                case "break":
                    e.takeBreak();
                    // break can resolve low energy/stress problems
                    errorMap.remove(e.getId());
                    JOptionPane.showMessageDialog(this, e.getName() + " break requested.");
                    break;
                case "train":
                    try {
                        e.train();
                        errorMap.remove(e.getId());
                        JOptionPane.showMessageDialog(this, e.getName() + " started training.");
                    } catch (LowEnergyException ex) {
                        errorMap.put(e.getId(), "ACTION: " + ex.getMessage());
                        showSelectedDetails();
                        JOptionPane.showMessageDialog(this, ex.getMessage(), "Action blocked",
                                JOptionPane.WARNING_MESSAGE);
                    }
                    break;
                case "reward":
                    e.reward();
                    errorMap.remove(e.getId());
                    JOptionPane.showMessageDialog(this, e.getName() + " rewarded.");
                    break;
            }
            refreshEmployees();
        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Employee not found", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onStopAction() {
        JPasswordField pf = new JPasswordField();
        int okCxl = JOptionPane.showConfirmDialog(this, pf, "Enter manager password:", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (okCxl != JOptionPane.OK_OPTION)
            return;
        String pw = new String(pf.getPassword()).trim();
        if (!manager.authenticate(pw)) {
            JOptionPane.showMessageDialog(this, "Invalid manager password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Integer id = getSelectedEmployeeId();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Select an employee first.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            Employee e = manager.getEmployee(id);
            e.setStatus(EmployeeStatus.IDLE);
            e.setBusyTicks(0);
            // clear any stored error for this employee when manager stops action
            errorMap.remove(e.getId());
            JOptionPane.showMessageDialog(this, "Stopped current action for " + e.getName());
            refreshEmployees();
        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Employee not found", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onReactivate() {
        JPasswordField pf = new JPasswordField();
        int okCxl = JOptionPane.showConfirmDialog(this, pf, "Enter manager password:", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (okCxl != JOptionPane.OK_OPTION)
            return;
        String pw = new String(pf.getPassword()).trim();
        if (!manager.authenticate(pw)) {
            JOptionPane.showMessageDialog(this, "Invalid manager password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Integer id = getSelectedEmployeeId();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Select an employee first.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            String eStr = JOptionPane.showInputDialog(this, "Set energy (1-100):", "50");
            String sStr = JOptionPane.showInputDialog(this, "Set stress (0-99):", "20");
            String pStr = JOptionPane.showInputDialog(this, "Set productivity (1-100):", "50");
            int en = Integer.parseInt(eStr);
            int st = Integer.parseInt(sStr);
            int pr = Integer.parseInt(pStr);
            manager.reactivateEmployee(id, en, st, pr);
            // clear any stored error when reactivated
            errorMap.remove(id);
            JOptionPane.showMessageDialog(this, "Employee reactivated.");
            refreshEmployees();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid numeric input", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Employee not found", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onSave() {
        // Require manager password to save
        JPasswordField pf = new JPasswordField();
        int okCxl = JOptionPane.showConfirmDialog(this, pf, "Enter manager password to save:",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (okCxl != JOptionPane.OK_OPTION)
            return;
        String pw = new String(pf.getPassword()).trim();
        if (!manager.authenticate(pw)) {
            JOptionPane.showMessageDialog(this, "Invalid manager password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            PersistenceManager.saveEmployees(manager.getAllEmployees(), "employees.dat");
            JOptionPane.showMessageDialog(this, "Saved employees.dat");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Save failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onLoad() {
        // Require manager password to load
        JPasswordField pf = new JPasswordField();
        int okCxl = JOptionPane.showConfirmDialog(this, pf, "Enter manager password to load:",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (okCxl != JOptionPane.OK_OPTION)
            return;
        String pw = new String(pf.getPassword()).trim();
        if (!manager.authenticate(pw)) {
            JOptionPane.showMessageDialog(this, "Invalid manager password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            List<com.simulator.core.Employee> list = PersistenceManager.loadEmployees("employees.dat");
            for (Employee e : list) {
                manager.addExistingEmployee(e);
            }
            JOptionPane.showMessageDialog(this, "Loaded employees.dat");
            refreshEmployees();
        } catch (IOException | ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Load failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onExit() {
        sim.stopSimulation();
        dispose();
    }
}
