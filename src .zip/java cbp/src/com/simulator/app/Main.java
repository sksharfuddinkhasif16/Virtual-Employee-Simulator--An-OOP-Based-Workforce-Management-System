package com.simulator.app;

import com.simulator.core.Employee;
import com.simulator.manager.EmployeeManager;
import com.simulator.persistence.PersistenceManager;
import com.simulator.sim.SimulationThread;
import com.simulator.exceptions.*;

import java.io.Console;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

/**
 * Console app entry point. Provides simple manager/user menu:
 * - add employee (manager)
 * - perform action on employee (work/break/train/reward)
 * - show statuses
 * - save/load
 */
public class Main {
    private static final String DATA_FILE = "employees.dat";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeManager manager = new EmployeeManager();
        SimulationThread sim = new SimulationThread(manager, 2000); // faster ticks for demonstration
        sim.start();

        boolean running = true;
        while (running) {
            showMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> addEmployee(sc, manager);
                    case "2" -> performAction(sc, manager);
                    case "3" -> manager.showAllEmployees();
                    case "4" -> saveEmployees(manager, sc);
                    case "5" -> loadEmployees(manager, sc);
                    case "6" -> running = false;
                    case "7" -> reactivateEmployee(sc, manager);
                    case "8" -> stopCurrentAction(sc, manager);
                    default -> System.out.println("Invalid option. Enter 1-8.");
                }
            } catch (Exception ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }

        sim.stopSimulation();
        System.out.println("Goodbye!");
        sc.close();
    }

    private static void showMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Add Employee (Manager)");
        System.out.println("2. Perform Action on Employee (User)");
        System.out.println("3. Show All Employee Status");
        System.out.println("4. Save Employees to File");
        System.out.println("5. Load Employees from File");
        System.out.println("6. Exit");
        System.out.println("7. Reactivate Employee (Manager)");
        System.out.println("8. Stop Current Action (Manager)");
        System.out.print("Choice: ");
    }

    private static void reactivateEmployee(Scanner sc, EmployeeManager manager) {
        String pw = promptManagerPassword(sc);
        if (!manager.authenticate(pw)) {
            System.out.println("Invalid manager password. Cannot reactivate employee.");
            return;
        }

        try {
            System.out.print("Enter Employee ID to reactivate: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            System.out.print("Set Energy (1-100): ");
            int energy = Integer.parseInt(sc.nextLine().trim());
            System.out.print("Set Stress (0-99): ");
            int stress = Integer.parseInt(sc.nextLine().trim());
            System.out.print("Set Productivity (1-100): ");
            int productivity = Integer.parseInt(sc.nextLine().trim());

            manager.reactivateEmployee(id, energy, stress, productivity);
            System.out.println("Employee " + id + " reactivated.");
        } catch (NumberFormatException ex) {
            System.out.println("Invalid number input.");
        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void addEmployee(Scanner sc, EmployeeManager manager) {
        String pw = promptManagerPassword(sc);
        if (!manager.authenticate(pw)) {
            System.out.println("Invalid manager password. Cannot add employee.");
            return;
        }
        System.out.print("Enter name: ");
        String name = sc.nextLine().trim();
        System.out.println("Choose role: 1. Developer  2. Tester  3. Designer");
        String r = sc.nextLine().trim();
        String role = switch (r) {
            case "1" -> "Developer";
            case "2" -> "Tester";
            case "3" -> "Designer";
            default -> {
                System.out.println("Invalid role, defaulting to Developer.");
                yield "Developer";
            }
        };

        System.out.print("Starting Productivity (0-100): ");
        int p = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Starting Stress (0-100): ");
        int s = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Starting Energy (0-100): ");
        int e = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Starting Skills (0-100): ");
        int sk = Integer.parseInt(sc.nextLine().trim());
        // Optional: allow setting ID explicitly
        System.out.print("Enter ID (leave blank for auto): ");
        String idLine = sc.nextLine().trim();
        Employee emp;
        try {
            if (idLine.isEmpty()) {
                // EmployeeManager expects (role, name, productivity, stress, energy, skills)
                emp = manager.createEmployee(role, name, p, s, e, sk);
            } else {
                int id = Integer.parseInt(idLine);
                emp = manager.createEmployeeWithId(role, name, id, p, s, e, sk);
            }
        } catch (NumberFormatException ex) {
            System.out.println("Invalid ID number. Aborting add.");
            return;
        } catch (IllegalArgumentException ex) {
            System.out.println("Failed to add employee: " + ex.getMessage());
            return;
        }
        System.out.println("Added employee with ID: " + emp.getId());
    }

    private static void performAction(Scanner sc, EmployeeManager manager) throws EmployeeNotFoundException {
        System.out.print("Enter Employee ID: ");
        int id = Integer.parseInt(sc.nextLine().trim());
        Employee e = manager.getEmployee(id);

        System.out.println("Actions: 1. Work  2. Break  3. Train  4. Reward  5. Show Status");
        String act = sc.nextLine().trim();

        try {
            switch (act) {
                case "1" -> e.work();
                case "2" -> e.takeBreak();
                case "3" -> e.train();
                case "4" -> e.reward();
                case "5" -> e.showStatus();
                default -> System.out.println("Invalid action.");
            }
            // Debug: print immediate status after the requested action
            System.out.println("[DEBUG] Immediate status: " + e.getStatus());
        } catch (LowEnergyException | HighStressException ex) {
            System.out.println("⚠ " + ex.getMessage());
        }
    }

    private static void saveEmployees(EmployeeManager manager, Scanner sc) {
        String pw = promptManagerPassword(sc);
        if (!manager.authenticate(pw)) {
            System.out.println("Invalid manager password. Save aborted.");
            return;
        }
        try {
            PersistenceManager.saveEmployees(manager.getAllEmployees(), DATA_FILE);
            System.out.println("Saved employees to " + DATA_FILE);
        } catch (IOException ex) {
            System.out.println("Failed to save: " + ex.getMessage());
        }
    }

    private static void loadEmployees(EmployeeManager manager, Scanner sc) {
        String pw = promptManagerPassword(sc);
        if (!manager.authenticate(pw)) {
            System.out.println("Invalid manager password. Load aborted.");
            return;
        }
        try {
            List<Employee> list = PersistenceManager.loadEmployees(DATA_FILE);
            for (Employee e : list) {
                // Manager method is named addExistingEmployee
                manager.addExistingEmployee(e);
            }
            System.out.println("Loaded " + list.size() + " employees from file: " + DATA_FILE);
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Failed to load: " + ex.getMessage());
        }
    }

    private static void stopCurrentAction(Scanner sc, EmployeeManager manager) {
        String pw = promptManagerPassword(sc);
        if (!manager.authenticate(pw)) {
            System.out.println("Invalid manager password. Cannot stop action.");
            return;
        }

        try {
            System.out.print("Enter Employee ID to stop current action: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            com.simulator.core.Employee e = manager.getEmployee(id);
            e.setBusyTicks(0);
            e.setStatus(com.simulator.core.EmployeeStatus.IDLE);
            System.out.println("Stopped current action for employee " + id + ". Status is now IDLE.");
        } catch (NumberFormatException ex) {
            System.out.println("Invalid number input.");
        } catch (com.simulator.exceptions.EmployeeNotFoundException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // Prompt manager password with masking when possible. Falls back to Scanner
    // input
    // when running in environments where System.console() is not available (IDE).
    private static String promptManagerPassword(Scanner sc) {
        Console console = System.console();
        if (console != null) {
            char[] pass = console.readPassword("Enter manager password: ");
            return pass == null ? "" : new String(pass).trim();
        }
        // Fallback for when running inside IDEs where Console is null
        System.out.print("Enter manager password (input not masked): ");
        return sc.nextLine().trim();
    }
}
