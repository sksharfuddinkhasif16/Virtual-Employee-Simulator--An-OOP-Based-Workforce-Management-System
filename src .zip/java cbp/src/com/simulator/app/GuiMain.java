package com.simulator.app;

import com.simulator.manager.EmployeeManager;
import com.simulator.sim.SimulationThread;
import com.simulator.app.ui.MainFrame;

import javax.swing.*;

public class GuiMain {
    public static void main(String[] args) {
        // Create manager and simulation thread here so UI can interact with them
        EmployeeManager manager = new EmployeeManager();
        SimulationThread sim = new SimulationThread(manager, 2000);
        sim.start();

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame(manager, sim);
            frame.setVisible(true);
        });
    }
}
